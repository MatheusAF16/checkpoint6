import React from 'react';

export default function Rodape() {
  return (
    <footer className="porto-seguro-rodape">
      <p>Final da página.</p>
    </footer>
  );
}
