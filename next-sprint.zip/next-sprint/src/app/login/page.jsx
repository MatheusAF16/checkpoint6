"use client"
import React, { useState } from "react";
import Link from 'next/link';

export default function Login() {
  const [credenciais, setCredenciais] = useState({
    usuario: "",
    senha: "",
  });

  const handleChange = (e) => {
    setCredenciais({ ...credenciais, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Lógica de autenticação aqui (por enquanto, apenas exibindo no console)
    console.log("Usuário:", credenciais.usuario);
    console.log("Senha:", credenciais.senha);
  };

  return (
    <main className="porto-seguro-login">
      <h1 className="login-title">Login</h1>
      <form onSubmit={handleSubmit} className="login-form">
        <label className="login-label">Usuário:</label>
        <br />
        <input
          type="text"
          name="usuario"
          value={credenciais.usuario}
          onChange={handleChange}
          className="login-input"
        />
        <br />
        <label className="login-label">Senha:</label>
        <br />
        <input
          type="password"
          name="senha"
          value={credenciais.senha}
          onChange={handleChange}
          className="login-input"
        />
        <br />
        <Link href={'./contausuario'} className="login-link">Fazer Login</Link>
      </form>
    </main>
  );
}