"use client"
import React, { useState } from 'react';
import Link from 'next/link';

export default function CadastroPage() {
  const [formData, setFormData] = useState({
    nome: '',
    cpf: '',
    rg: '',
    telefone: '',
    email: '',
    endereco: {
      rua: '',
      numero: '',
      cep: '',
      cidade: '',
      bairro: '',
      estado: '',
    },
    bicicleta: {
      modelo: '',
      marca: '',
      numeroSerie: '',
      numeroMarchas: '',
      cor: '',
      valor: '',
    },
    plano: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:8080/Sprint4/api/proprietario', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ proprietario: formData }),
      });

      if (response.ok) {
        console.log('Formulário enviado com sucesso!');
        // Redirecionar ou realizar outras ações após o sucesso
      } else {
        console.error('Erro ao enviar formulário:', response.statusText);
      }
    } catch (error) {
      console.error('Erro ao enviar formulário:', error.message);
    }
  };

  return (
    <div className="cadastro-page">
      <h1 className="cadastro-title">Cadastro</h1>
      <form className="cadastro-form" onSubmit={handleSubmit}>
        {/* Seção de Dados Pessoais */}
        <label className="form-label">Nome:</label>
        <input type="text" name="nome" className="form-input" onChange={handleChange} />

        <label className="form-label">CPF:</label>
        <input type="text" name="cpf" className="form-input" onChange={handleChange} />

        <label className="form-label">RG:</label>
        <input type="text" name="rg" className="form-input" onChange={handleChange} />

        <label className="form-label">Telefone:</label>
        <input type="text" name="telefone" className="form-input" onChange={handleChange} />

        <label className="form-label">Email:</label>
        <input type="text" name="email" className="form-input" onChange={handleChange} />

        {/* Seção de Endereço */}
        <h2 className="form-section-title">Endereço</h2>
        <label className="form-label">Rua:</label>
        <input type="text" name="rua" className="form-input" onChange={handleChange} />

        <label className="form-label">Número:</label>
        <input type="text" name="numero" className="form-input" onChange={handleChange} />

        <label className="form-label">CEP:</label>
        <input type="text" name="cep" className="form-input" onChange={handleChange} />

        <label className="form-label">Cidade:</label>
        <input type="text" name="cidade" className="form-input" onChange={handleChange} />

        <label className="form-label">Bairro:</label>
        <input type="text" name="bairro" className="form-input" onChange={handleChange} />

        <label className="form-label">Estado:</label>
        <input type="text" name="estado" className="form-input" onChange={handleChange} />

        {/* Seção da Bicicleta */}
        <h2 className="form-section-title">Bicicleta</h2>
        <label className="form-label">Modelo:</label>
        <input type="text" name="modelo" className="form-input" onChange={handleChange} />

        <label className="form-label">Marca:</label>
        <input type="text" name="marca" className="form-input" onChange={handleChange} />

        <label className="form-label">Número de Série:</label>
        <input type="text" name="numeroSerie" className="form-input" onChange={handleChange} />

        <label className="form-label">Número de Marchas:</label>
        <input type="text" name="numeroMarchas" className="form-input" onChange={handleChange} />

        <label className="form-label">Cor:</label>
        <input type="text" name="cor" className="form-input" onChange={handleChange} />

        <label className="form-label">Valor:</label>
        <input type="text" name="valor" className="form-input" onChange={handleChange} />

        {/* Seção de Planos */}
        <h2 className="form-section-title">Planos</h2>
        <label className="form-radio">
          <input
            type="radio"
            name="plano"
            value="Plano A"
            onChange={handleChange}
            checked={formData.plano === 'Plano A'}
          />
          Plano A
        </label>

        <label className="form-radio">
          <input
            type="radio"
            name="plano"
            value="Plano B"
            onChange={handleChange}
            checked={formData.plano === 'Plano B'}
          />
          Plano B
        </label>

        <label className="form-radio">
          <input
            type="radio"
            name="plano"
            value="Plano C"
            onChange={handleChange}
            checked={formData.plano === 'Plano C'}
          />
          Plano C
        </label>

        <label className="form-radio">
          <input
            type="radio"
            name="plano"
            value="Plano D"
            onChange={handleChange}
            checked={formData.plano === 'Plano D'}
          />
          Plano D
        </label>

        {/* Botão de Concluir Cadastro */}
        <button type="submit" className="form-button">
          Fazer Cadastro
        </button>
      </form>
    </div>
  );
}
