import { useEffect, useState } from "react";

export default function Criar({ params }) {
  const prodId = params.id === 0 ? '' : params.id;

  const [novo, setNovo] = useState({
    nome: '',
    cpf: '',
    rg: '',
    telefone: '',
    email: '',
    endereco: {
      rua: '',
      numero: '',
      cep: '',
      cidade: '',
      bairro: '',
      estado: '',
    },
    bicicleta: {
      modelo: '',
      marca: '',
      numeroSerie: '',
      numeroMarchas: '',
      cor: '',
      valor: '',
    },
    plano: '',
  });

  let metodo = 'post';
  if (prodId) metodo = 'put';

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNovo({ ...novo, [name]: value });
  };

  const handleEnderecoChange = (e) => {
    const { name, value } = e.target;
    setNovo((prev) => ({
      ...prev,
      endereco: {
        ...prev.endereco,
        [name]: value,
      },
    }));
  };

  const handleBicicletaChange = (e) => {
    const { name, value } = e.target;
    setNovo((prev) => ({
      ...prev,
      bicicleta: {
        ...prev.bicicleta,
        [name]: value,
      },
    }));
  };

  const handlePlanoChange = (e) => {
    setNovo((prev) => ({
      ...prev,
      plano: e.target.value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`http://localhost:5000/cadastro/${prodId}`, {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novo),
    })
      .then((window.location = "/"))
      .catch((error) => console.error(error));
  };

  useEffect(() => {
    if (prodId) {
      fetch(`http://localhost:5000/cadastro/${prodId}`)
        .then((resp) => resp.json())
        .then((resp) => setNovo(resp))
        .catch((error) => console.error(error));
    }
  }, [prodId]);

  return (
    <main>
      <h1>Formulário Produtos</h1>

      <form onSubmit={handleSubmit}>
        {/* Dados Pessoais */}
        <label>Nome:</label>
        <input type="text" name="nome" value={novo.nome} onChange={handleChange} /> <br />
        <label>CPF:</label>
        <input type="text" name="cpf" value={novo.cpf} onChange={handleChange} /> <br />
        {/* Adicione os outros campos de dados pessoais aqui */}

        {/* Endereço */}
        <h2>Endereço</h2>
        <label>Rua:</label>
        <input
          type="text"
          name="rua"
          value={novo.endereco.rua}
          onChange={handleEnderecoChange}
        />{" "}
        <br />
        {/* Adicione os outros campos de endereço aqui */}

        {/* Bicicleta */}
        <h2>Bicicleta</h2>
        <label>Modelo:</label>
        <input
          type="text"
          name="modelo"
          value={novo.bicicleta.modelo}
          onChange={handleBicicletaChange}
        />{" "}
        <br />
        {/* Adicione os outros campos da bicicleta aqui */}

        {/* Planos */}
        <h2>Planos</h2>
        <label>
          <input
            type="radio"
            name="plano"
            value="Plano A"
            checked={novo.plano === "Plano A"}
            onChange={handlePlanoChange}
          />
          Plano A
        </label>{" "}
        <br />
        {/* Adicione os outros planos aqui */}

        {/* Botão de Concluir Cadastro */}
        <button type="submit">Enviar</button>
      </form>
    </main>
  );
}
