export default function Servico(){

    return(
        <main className="porto-seguro-servico">
        <h1 className="porto-seguro-title">Serviços</h1>
        <p className="porto-seguro-paragraph">Nossos serviços!!!</p>
      </main>
    )
}