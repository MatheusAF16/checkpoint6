import React from 'react';

export default function Impressao() {
  return (
    <main className="porto-seguro-impressao">
      <h1 className="porto-seguro-title">Serviço de Impressão!</h1>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
    </main>
  );
}
