// ./src/app/novavistoria/page.jsx

"use client";
import { useState } from 'react';
import Link from 'next/link';

const NovaVistoriaPagina = () => {
  const [dadosVistoria, setDadosVistoria] = useState({
    nomePeca: '',
    preco: '',
    fabricante: '',
    linkNormal: '',
    linkDanificado: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDadosVistoria((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Lógica para enviar os dados da vistoria para o servidor
    console.log('Dados da Nova Vistoria enviados:', dadosVistoria);
    // Você pode adicionar a lógica para enviar os dados para o servidor aqui

    // Redireciona de volta para a página da conta do usuário após o envio
    window.location.href = '/contausuario';
  };

  return (
    <div className="porto-seguro-nova-vistoria">
      <header className="porto-seguro-header">
        <h1>Nova Vistoria</h1>
      </header>

      <form onSubmit={handleSubmit} className="porto-seguro-form">
        <label className="porto-seguro-label">Nome da Peça:</label>
        <input type="text" name="nomePeca" onChange={handleChange} className="porto-seguro-input" />

        <label className="porto-seguro-label">Preço:</label>
        <input type="text" name="preco" onChange={handleChange} className="porto-seguro-input" />

        <label className="porto-seguro-label">Fabricante:</label>
        <input type="text" name="fabricante" onChange={handleChange} className="porto-seguro-input" />

        <label className="porto-seguro-label">Link Normal:</label>
        <input type="text" name="linkNormal" onChange={handleChange} className="porto-seguro-input" />

        <label className="porto-seguro-label">Link Danificado:</label>
        <input type="text" name="linkDanificado" onChange={handleChange} className="porto-seguro-input" />

        <button type="submit" className="porto-seguro-button">Enviar</button>
        <br />
        <br />
        <Link href="/contausuario">
          <button className="porto-seguro-button">Voltar para Minha Conta</button>
        </Link>
      </form>
    </div>
  );
};

export default NovaVistoriaPagina;



