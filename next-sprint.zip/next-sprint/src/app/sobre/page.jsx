import React from 'react';

const Sobre = () => {
  return (
    <div className="porto-seguro-sobre">
      <h2>Somos a companhia que está com você em todos os momentos da vida</h2>
      <h3>A Porto é mais do que uma seguradora: é um ecossistema com todas as soluções para transformar sonhos em realidades diárias. </h3>
      <br />
      <h3>Com mais de 75 anos de mercado, possui hoje três verticais de negócios: Porto Seguros, Porto Saúde e Porto Seguro Bank, formando, assim, um conjunto de soluções de proteção para os seus momentos que vão desde o dia a dia até o grande dia</h3>
      <br />
      <h2>Começamos essa jornada com você lá atrás.</h2>
      <h3>E estivemos presentes quando você mais precisou! Assista nosso manifesto na íntegra.</h3>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/i76-cKGXS64?si=1gE3NbkBpxKObk7B" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen></iframe>
    </div>
  );
}

export default Sobre;
