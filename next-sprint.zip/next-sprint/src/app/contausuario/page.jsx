"use client" // componente do cliente - Ele tem conteúdo dinâmico
import Link from "next/link";
import { useEffect, useState } from "react";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function PaginaDeVistorias() {
  const [vistorias, setVistorias] = useState([]);
  const [planos, setPlanos] = useState([]);
  const [enderecos, setEnderecos] = useState([]);
  const [bicicletas, setBicicletas] = useState([]);

  useEffect(() => {
    // Fetch vistorias
    fetch(`http://localhost:8080/Sprint4/api/proprietario`)
      .then((resp) => resp.json())
      .then((resp) => setVistorias(resp.map((v) => ({
        id: v.idProprietario,
        nome: v.nome,
        cpf: v.cpf,
        rg: v.rg, // Adicione esta linha para incluir o campo RG
        telefone: v.telefone, // Adicione esta linha para incluir o campo Telefone
        email: v.email,
      }))))
      .catch((error) => console.error(error));


      fetch(`http://localhost:8080/Sprint4/api/endereco`)
      .then((resp) => resp.json())
      .then((resp) => setEnderecos(resp.map((endereco) => ({
        id: endereco.idEndereco,
        cep: endereco.cep,
        logradouro: endereco.rua,
        complemento: endereco.complemento,
        bairro: endereco.bairro,
        localidade: endereco.cidade,
        uf: endereco.estado,
        numero: endereco.numero,
      }))))
      .catch((error) => console.error(error));
  
    // Fetch bicicletas
    fetch(`http://localhost:8080/Sprint4/api/bicicleta`)
      .then((resp) => resp.json())
      .then((resp) => setBicicletas(resp.map((bicicleta) => ({
        id: bicicleta.idBicicleta,
        modelo: bicicleta.modelo,
        marca: bicicleta.marca,
        numeroSerie: bicicleta.numeroSerie,
        numeroMarchas: bicicleta.numeroMarchas,
        cor: bicicleta.cor,
        valor: bicicleta.valor,
      }))))
      .catch((error) => console.error(error));

    // Fetch planos
    fetch(`http://localhost:8080/Sprint4/api/planos`)
      .then((resp) => resp.json())
      .then((resp) => setPlanos(resp.map((p) => ({
        id: p.idPlano,
        plano: p.plano,
        cotacao: p.cotacao,
        beneficios: p.beneficios,
        // Adicione mais campos conforme necessário
      }))))
      .catch((error) => console.error(error));

    // Fetch endereços
    fetch(`http://localhost:8080/Sprint4/api/endereco`)
      .then((resp) => resp.json())
      .then((resp) => setEnderecos(resp.map((e) => ({
        id: e.idEndereco,
        cep: e.cep,
        logradouro: e.logradouro,
        complemento: e.complemento,
        bairro: e.bairro,
        localidade: e.localidade,
        uf: e.uf,
        numero: e.numero,
        // Adicione mais campos conforme necessário
      }))))
      .catch((error) => console.error(error));

    // Fetch bicicletas
    fetch(`http://localhost:8080/Sprint4/api/bicicleta`)
      .then((resp) => resp.json())
      .then((resp) => setBicicletas(resp.map((b) => ({
        id: b.idBicicleta,
        modelo: b.modelo,
        marca: b.marca,
        numeroSerie: b.numeroSerie,
        numeroMarchas: b.numeroMarchas,
        cor: b.cor,
        valor: b.valor,
        // Adicione mais campos conforme necessário
      }))))
      .catch((error) => console.error(error));
  }, []);

  return (
    <main className="porto-seguro-conta-usuario">
      <h1>Conta do Usuário </h1>
      <Link href={'./vistoriapagina'} className="porto-seguro-link">Consultar Vistorias</Link>
      <Link href={'./'} className="porto-seguro-link">Fazer Logout</Link>

      <table className="porto-seguro-table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>CPF</th>
            <th>RG</th> 
            <th>Telefone</th> 
            <th>Email</th> 
            <th>CEP</th> 
            <th>Logradouro</th> 
            <th>Complemento</th> 
            <th>Bairro</th> 
            <th>Localidade</th> 
            <th>UF</th> 
            <th>Número</th> 
            <th>Modelo Bicicleta</th>
            <th>Marca Bicicleta</th>
            <th>Número de Série Bicicleta</th>
            <th>Número de Marchas Bicicleta</th>
            <th>Cor Bicicleta</th>
            <th>Valor Bicicleta</th>
          </tr>
        </thead>
        <tbody>
          {vistorias.map((vistoria, index) => (
            <tr key={index}>
              <td>{vistoria.nome}</td>
              <td>{vistoria.cpf}</td>
              <td>{vistoria.rg}</td>
              <td>{vistoria.telefone}</td>
              <td>{vistoria.email}</td>
              <td>{enderecos[index]?.cep || 'Não disponível'}</td>
              <td>{enderecos[index]?.logradouro || 'Não disponível'}</td>
              <td>{enderecos[index]?.complemento || 'Não disponível'}</td>
              <td>{enderecos[index]?.bairro || 'Não disponível'}</td>
              <td>{enderecos[index]?.localidade || 'Não disponível'}</td>
              <td>{enderecos[index]?.uf || 'Não disponível'}</td>
              <td>{enderecos[index]?.numero || 'Não disponível'}</td>
              <td>{bicicletas[index]?.modelo || 'Não disponível'}</td>
              <td>{bicicletas[index]?.marca || 'Não disponível'}</td>
              <td>{bicicletas[index]?.numeroSerie || 'Não disponível'}</td>
              <td>{bicicletas[index]?.numeroMarchas || 'Não disponível'}</td>
              <td>{bicicletas[index]?.cor || 'Não disponível'}</td>
              <td>{bicicletas[index]?.valor || 'Não disponível'}</td>

            </tr>
          ))}
        </tbody>
        {/* Repita a estrutura acima para planos, endereços e bicicletas */}
      </table>
    </main>
  );
}

