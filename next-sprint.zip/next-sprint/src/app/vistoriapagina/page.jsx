"use client" // client component - Ele tem conteúdo dinâmico
import Link from "next/link"
import { useEffect, useState } from "react"
import {FaEdit, FaTrash} from 'react-icons/fa'

export default function VistoriaPagina() {
  const [vistorias, setVistorias] = useState([]);

  useEffect(() => {
    const fetchVistorias = async () => {
      try {
        const response = await fetch('http://localhost:8080/Sprint4/api/relatoriovistoria');
        if (response.ok) {
          const data = await response.json();
          setVistorias(data);
        } else {
          console.error('Erro ao buscar vistorias:', response.statusText);
        }
      } catch (error) {
        console.error('Erro ao buscar vistorias:', error);
      }
    };

    fetchVistorias();
  }, []);

  return (
    <div className="vistoria-pagina">
      <header>
        <h1 className="titulo">Lista de Vistorias</h1>
      </header>

      <section className="lista-vistorias">
        {vistorias.map((vistoria) => (
          <div key={vistoria.id} className="item-vistoria">
            <h2>Vistoria {vistoria.id}</h2>
            <p>Data da vistoria: {vistoria.data}</p>
            <p>Relatório: {vistoria.relatorio}</p>
          </div>
        ))}
      </section>

      <section className="botoes">
        <Link href="/novavistoria">
          <button className="botao-vistoria">Fazer Nova Vistoria</button>
        </Link>
        <Link href="/contausuario">
          <button className="botao-voltar">Voltar para Conta do Usuário</button>
        </Link>
      </section>
    </div>
  );
}

